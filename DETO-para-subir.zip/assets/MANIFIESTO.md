# Manifiesto de assets

Todos los archivos son locales; el código no contiene URLs de Figma.

## Iconos (`icons/`, SVG, `currentColor` vía máscara CSS cuando cambian de color)
| Grupo | Archivos | Origen |
|---|---|---|
| Navegación | nav-inicio, nav-tendencias, nav-lab, nav-calendario, nav-catalogo, informe-documento | Exportados de los frames (SVG) |
| Header | header-buscar, header-campana, header-chevron | Frames |
| KPIs | kpi-grafico-tendencia, kpi-objetivo, kpi-calendario | Frames |
| Carrusel | flecha-anterior, flecha-siguiente, tendencia-subida, flecha-derecha-blanca, flecha-arriba-derecha, metrica-busqueda/carrito/usuarios | Frames / Figma Make |
| LAB | lab-tienda, lab-calendario, lab-ojo, lab-flecha, flecha-derecha-naranja | Frames |
| Tendencias (`tend-*.svg`) | guardar, guardar-relleno, mas, filtros, cerrar, chevron-abajo/derecha, vista-grilla/lista, flecha-derecha, estrella, carrito, barras, crecimiento, busqueda, conversacion, etiqueta-precio, tienda, usuarios, check | Trazos de `Icon.tsx` del Figma Make, exportados como SVG (máscara CSS, color por `currentColor`) |
| Catálogo (`cat-*.svg`) | cat-botella, cat-cigarrillo, cat-canasta, cat-panaderia, cat-gota, cat-huella, cat-caja, cat-rayo (íconos de macrocategoría; el de "Despensa y productos" reutiliza `cal-catalogo.svg`). Chevrones, check, filtros, búsqueda, tendencia, info, tienda y guardar reutilizan los de Tendencias/Calendario | Trazos de `Icon.tsx` del Figma Make |
| Calendario | calendario-anterior, calendario-siguiente, calendario-agregar, evento-icono, evento-flecha | Frames |

## Imágenes (`img/`, PNG)
| Archivo | Uso | Origen |
|---|---|---|
| logo-deto.png | Logo del sidebar | Figma Make (versión DETO); baja resolución |
| blob-verde.png | Mancha verde tras el producto | Figma Make |
| producto-snacks-proteicos.png, barra-snack-proteico.png | Slide 1 | Frames |
| producto-yogurt-griego.png | Slide 2 y peek | Figma Make |
| producto-matcha-latte.png | Slide 3 y peek | Figma Make |
| lab-tequenos-manqueseo.png, lab-gams-protein-chips.png | Pilotos LAB | Frames |

| tendencia-matcha-latte, -oreo-halloween, -electrolit-uva, -takis-fuego, -chocolate-sahne-nuss, -yogurt-griego (.png) | Cards, filas y panel de Tendencias | Figma Make (`public/assets/radaro/`) |

| catalogo-producto-placeholder.svg | Imagen neutra del producto en el detalle de Catálogo (pendiente de la imagen real) | Creada para el proyecto |

## Fuentes (`fonts/`)
Montserrat latin 400/500/600/700/800 (woff2).

Para mejorar el logo u otros PNG: exportar el nodo desde Figma a 2× y reemplazar el archivo con el mismo nombre.

| Calendario | cal-objetivo, cal-rayo, cal-bolsa, cal-mas, cal-chevron-izquierda/derecha/abajo, cal-info, cal-carrito, cal-barras, cal-trofeo, cal-catalogo, cal-calendario, cal-chispas, cal-tendencia, cal-flecha, cal-tienda, cal-conversacion, cal-busqueda, cal-cerrar, cal-en-alza | Trazados del Icon.tsx del Make (SVG, máscara CSS). Imágenes de producto: las de Tendencias |

| lab-chocolate-con-leche-250g.png | Producto Chocolate con Leche 250 g en LAB (mismo del frame) | Figma Make (`sahne-nuss.png`) |
| lab-matraz.svg | Ícono LAB (matraz) en la pantalla | Trazado de `Icon.tsx` del Make |
